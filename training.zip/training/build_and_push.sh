#!/bin/bash

# 設置變數
IMAGE_NAME="triton"
TAG="jupyter-20250302-readonly"
REGISTRY="cloudinfra-registry.ubilink.ai"
PROJECT_ID="02b62aba-db1e-42a1-8278-9d778445794d"

# 顯示開始訊息
echo "開始構建 Docker 映像..."

# 構建 Docker 映像
docker build  -f Dockerfile -t ${IMAGE_NAME}:${TAG} .

# 檢查構建是否成功
if [ $? -eq 0 ]; then
    echo "Docker 映像構建成功"
    
    # 標記映像
    docker tag ${IMAGE_NAME}:${TAG} ${REGISTRY}/${PROJECT_ID}/${IMAGE_NAME}:${TAG}
    
    # 推送到遠端倉庫
    echo "推送映像到遠端倉庫..."
    docker push ${REGISTRY}/${PROJECT_ID}/${IMAGE_NAME}:${TAG}
    
    if [ $? -eq 0 ]; then
        echo "映像推送成功"
        echo "清理臨時構建目錄完成"
    else
        echo "錯誤：映像推送失敗"
        exit 1
    fi
else
    echo "錯誤：Docker 映像構建失敗"
    exit 1
fi 