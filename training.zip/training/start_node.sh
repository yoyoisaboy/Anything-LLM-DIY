#!/bin/bash

# 啟動 supervisor
/usr/bin/supervisord -n -c /etc/supervisor/conf.d/supervisord.conf &

# 啟動 Jupyter
jupyter lab --ip=0.0.0.0 \
           --port=8888 \
           --allow-root \
           --no-browser \
           --ServerApp.custom_display_url=${JUPYTER_CUSTOM_DISPLAY_URL} \
           --ServerApp.base_url=${JUPYTER_BASE_URL} \
           --ServerApp.token=${JUPYTER_TOKEN} 